package com.proj.team.domain;

import java.util.Objects;

public class UserDto {
	
	private String id;
	private String pass;
	
	public UserDto(String id, String pass) {
		this.id = id;
		this.pass = pass;
	}
	public UserDto() {}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	@Override
	public String toString() {
		return "UserDto [id=" + id + ", pass=" + pass + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, pass);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDto other = (UserDto) obj;
		return Objects.equals(id, other.id) && Objects.equals(pass, other.pass);
	}

	
	


}
